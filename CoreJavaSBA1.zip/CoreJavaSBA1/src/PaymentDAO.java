import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class PaymentDAO implements IPaymentDAO{

	List<Cheque> chequeList;
	
	public void insertPaymentDetails(List<Cheque> chequeList){
		
		chequeList= new ArrayList<Cheque>();
		
		Connection con = null;
		
		try {
			con = DBConnection.getConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Statement s = null;
	
	
		ResultSet rs = null;
		try {
			rs = s.executeQuery("select role.id,role.name,contact.street,contact.city,contact.state,user.name from role,contact,user where role.id=user.role_id and user.contact_id=contact.id order by user.name");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
	}
		
	
	
	public Payment getPaymentById(Integer paymentID){
			
			
			
			
		
		
	
	
	
	
		}
		
		
		
		
	
	
	
}
