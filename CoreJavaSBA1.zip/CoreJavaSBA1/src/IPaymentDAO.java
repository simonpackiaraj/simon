import java.util.List;


public interface IPaymentDAO  {
	
	
	public void insertPaymentDetails(List<Cheque> chequeList);
	
	

}
