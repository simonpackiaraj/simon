
public class InvalidPaymentException extends Exception{

private static final long serialversionId =1L;
	
	public InvalidPaymentException(String msg)
	{
		super(msg);
		
	}
	
}
