import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;








public class PaymentBO {

	List<Cheque> chequeList= new ArrayList<Cheque>();
	PaymentDAO paymentDAO;
	
	public List<Cheque> getChequeList(String[] fileData) throws IOException,ClassNotFoundException,SQLException,InvalidPaymentException{
		
		//fill the code
		
		String[] fileData1=fileData;
		
		int len = fileData1.length;
		System.out.println(len);
		 fileData1= new String[len];
		
		
			 for(int i=0; i<len; i++) {
	        	    
	        		
			 
			 String[] data= fileData[i].split(",");
			 
			 String pattern = "(INV){3}\\d{5}$";
		        Pattern pat = Pattern.compile(pattern);
		        Matcher match = pat.matcher(fileData1[2]);
		       
		  
			 if (match.matches())
				{
					
				 chequeList.add(new Cheque((new Integer(data[6])),data[7],data[8],(new Payment((new Integer(data[0])),data[1],data[2],new Integer(data[3]),new Double(data[4]),data[5]))));

				 paymentDAO.insertPaymentDetails(chequeList);
				 
				}
			 
			 
				 
			 else
				
					 throw new InvalidPaymentException("InvalidPaymentException:Invalid invoice number :"+fileData1[2]+"\nUpdate correct invoice number in file");
			 
			 }
			 return chequeList;	
			
		}
		
			 
			 
		
		
		
	   
		
	        

	
	public String[] getFileDetails() throws IOException{
		
		
		
		BufferedReader br= new BufferedReader(new FileReader("Payment.csv.txt"));
		
		//new FileReader("Payment.csv.txt"
		
		//String line = br.readLine();
		
		int length= 0;
			
	        while((br.readLine() != null) && !br.readLine().isEmpty())
	        
	        {
	        	
	        	length++;
		//fill the code
		
		
	        }	
	        System.out.println(br.readLine());
	        String[] lines= new String[length];
	        
	        
	        for(int i=0; i<length; i++) {
        	    
        	
        		lines[i] = br.readLine();
		
	}
	        return lines;
	}
}
	

