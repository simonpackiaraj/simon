import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Main {

	public static void main(String[] args) throws IOException,ClassNotFoundException,SQLException,InvalidPaymentException {
		// TODO Auto-generated method stub
		
		PaymentBO paymentBo = new PaymentBO();
		List<Cheque> chequeList= new ArrayList<Cheque>();
		
		try{
			//fill the code
			
			chequeList= paymentBo.getChequeList(paymentBo.getFileDetails());
		
			
			System.out.println("Payment and Cheque Details :");
			System.out.format("%-2s %-7s %-9s %-4s %-8s %-9s %-8s %-8s\n","Id","Customer","InvoiceNO","Attempt","Amount","Status","Bank","ChequeNO");
			
			for(Cheque c:chequeList){
				
				System.out.format("%-2s %-7s %-9s %-8s %-9s %-8s %-8s\n",c.getPayment().getId(),
	c.getPayment().getCustomerName(),c.getPayment().getInvoiceNumber(),c.getPayment().getAttempt(),
	c.getPayment().getAmount(),c.getPayment().getStatus(),c.getBankName(),c.getChequeNumber());
				
			}
			
			
		}
	
		
		catch(InvalidPaymentException e){
			
			
			//fill the code
			
			System.out.println(e.toString());
			
		}
		
		}
		
	}

	


